<?php
$connexion = new PDO("mysql:host=localhost; dbname=bdd_user", "root", "root");
?>